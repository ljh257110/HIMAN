package com.himan.content.service;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.himan.content.model.Comment;
public interface ICommentService {

	public void sendCM(Comment comment);

	public void deleteWB(String commentId);

}
