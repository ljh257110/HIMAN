package com.himan.content.service;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public interface ISearchMessage {
	/**
	 * Recording the log of this class.
	 */
	public List getMessages();
}
