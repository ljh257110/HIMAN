package com.himan.content.service.impl;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.himan.content.service.ISearchMessage;

public class SearchMessage implements ISearchMessage {
	/**
	 * Recording the log of this class.
	 */
	private final static Logger LOG = LogManager.getLogger(SearchMessage.class);

	
	@Resource
	public List getMessages() {
		// TODO Auto-generated method stub
		return null;
	}
}
